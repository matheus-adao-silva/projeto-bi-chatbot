--Consulte a quantidade de mensagens por inten��o no m�s de julho.
select intencoes.id as Id_intencao, intencoes.nome, COUNT(mensagens.FK_intencoes) Qtd
FROM mensagens,intencoes
WHERE mensagens.FK_intencoes = intencoes.id
AND MONTH(mensagens.data) = 07

GROUP BY intencoes.id, intencoes.nome
ORDER BY intencoes.id