--Consulte a quantidade de mensagens por uma inten��o de sua escolha por status no m�s de julho.
select intencoes.id as Id_intencao, intencoes.nome, COUNT(mensagens.FK_intencoes) Qtd, mensagens.status
FROM mensagens,intencoes
WHERE mensagens.FK_intencoes = intencoes.id
AND MONTH(mensagens.data) = 07
AND intencoes.id = 44

GROUP BY intencoes.id, intencoes.nome, mensagens.status
ORDER BY intencoes.id