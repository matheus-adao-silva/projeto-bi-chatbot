--Consulte a quantidade de mensagens enviados por usu�rio no m�s de julho.
select usuario.id as Id_usuario, usuario.nome, COUNT(mensagens.FK_usuario) Qtd
FROM mensagens,usuario
WHERE mensagens.FK_usuario = usuario.id
AND MONTH(mensagens.data) = 07

GROUP BY usuario.id, usuario.nome
ORDER BY usuario.id