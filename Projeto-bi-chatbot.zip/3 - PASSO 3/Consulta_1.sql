--Consulte a quantidade de usu�rios que acessaram no m�s de julho.
SELECT COUNT(id) QTD
FROM usuario
WHERE MONTH(usuario.data) = 07