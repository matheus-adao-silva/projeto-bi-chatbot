--Consulte as inten��es com maior % de aprova��o no m�s de julho.
select intencoes.id as Id_intencao, intencoes.nome, COUNT(mensagens.FK_intencoes) Qtd,cast( 100. * count(*) / sum(count(*)) over () as decimal(10,2)) as porcentagem
FROM mensagens,intencoes
WHERE mensagens.FK_intencoes = intencoes.id
AND MONTH(mensagens.data) = 07
AND mensagens.status = 'APROVADA'

GROUP BY intencoes.id, intencoes.nome, mensagens.status
ORDER BY intencoes.id